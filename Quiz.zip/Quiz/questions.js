//criando uma matriz e passando o número, perguntas, opções e respostas
let questions = [
    {
        numb:1,
        question: "Os Países Baixos também são conhecidos como...",
        answer:"Holanda",
        options:[
            "Portugal",
            "Reino Unido",
            "Holanda",
            "República Checa"
        ]
    },
    {
        numb:2,
        question: "Qual é o menor país do mundo?",
        answer: "Vaticano",
        options:[
            "Vaticano",
            "Marrocos",
            "Espanha",
            "Colômbia"
        ]
    },
    {
        numb:3,
        question: "A famosa Estátua da Liberdade é uma escultura localizada em...",
        answer: "Nova York",
        options:[
            "Washington",
            "Los Angeles",
            "Nova York",
            "Filadélfia"
        ]
    },
    {
        numb:4,
        question: "Qual a bandeira, entre os países abaixo, que não possui nenhum elemento na cor amarela?",
        answer: "Cuba",
        options:[
            "Argentina",
            "Brasil",
            "Uruguai",
            "Cuba"
        ]
    },
    {
        numb:5,
        question: "O maior dos continentes, tanto em área como em população, é a:",
        answer: "Ásia",
        options:[
            "Ásia",
            "África",
            "Europa",
            "América do Norte"
        ]
    },
    {
        numb:6,
        question: "Entre os estados brasileiros listados abaixo, qual fica mais próximo de São Paulo",
        answer: "Paraná",
        options:[
            "Espírito Santo",
            "Bahia",
            "Mato Grosso",
            "Paraná"
        ]
    },
    {
        numb:7,
        question: "Qual capital do Acre?",
        answer: "Rio Branco",
        options:[
            "Porto Velho",
            "Boa Vista",
            "Rio Branco",
            "São Luís"
        ]
    },
    {
        numb:8,
        question: "O que represetam as estrelas na bandeira do Brasil?",
        answer: "Os Estados e o Distrito Federal Brasileiro",
        options:[
            "A Esperança",
            "O orgulho de ser Brasileiro",
            "A Floresta Amazônica",
            "Os Estados e o Distrito Federal Brasileiro"
        ]
    },
    {
        numb:9,
        question: "Qual país tem a maior fronteira com o Brasil?",
        answer: "Bolívia",
        options:[
            "Venezuela",
            "Colômbia",
            "Peru",
            "Bolívia"
        ]
    },
    {
        numb:10,
        question: "Qual o nome dado aos desbravadores que contribuíram para a formação da fronteira brasileira?",
        answer: "Bandeirantes",
        options:[
            "Fronteiros",
            "Campineiros",
            "Estradeiros",
            "Bandeirantes"
        ]
    },
    {
        numb:11,
        question: "Quantos países da América do Sul fazer fronteira com o Brasil?",
        answer: "10",
        options:[
            "9",
            "10",
            "11",
            "12"
        ]
    },
    {
        numb:12,
        question: "O nome dado a linha imaginária entre dois estados ou municípios, é?",
        answer: "Limite",
        options:[
            "Território",
            "Limite",
            "Fronteira",
            "Regionalização"
        ]
    },
    {
        numb:13,
        question: "Dourados é um município brasileiro localizado no estado de:",
        answer: "Mato Grosso do Sul",
        options:[
            "Minas Gerais",
            "São Paulo",
            "Mato Grosso",
            "Mato Grosso do Sul"
        ]
    },
    {
        numb:14,
        question: "O que significa extravismo?",
        answer: "Extrair da natureza produtos para fins comerciais ou industriais",
        options:[
            "Ultilizar processos de escavação para a coleta e estudo de fósseis",
            "Estudo da estrutura extrema de um ser vivo",
            "Processo que investiga a existência de extraterrestres",
            "Extrair da natureza produtos para fins comerciais ou industriais"
        ]
    },
    {
        numb:15,
        question: "O rio São Francisco é populamente conhecido como:",
        answer: "Velho Chico",
        options:[
            "Chico Balanceado",
            "Chiquinho do Brasil",
            "Dois Filhos de Francisco",
            "Velho Chico"
        ]
    },
    {
        numb:16,
        question: "O país El Salvador está localizado na...",
        answer: "América Central",
        options:[
            "América do Sul",
            "América Central",
            "América do Norte",
            "Oceania"
        ]
    },
    {
        numb:17,
        question: "A região da Groenlândia pertence a qual país?",
        answer: "Dinamarca",
        options:[
            "Estados Unidos",
            "Dinamarca",
            "Canadá",
            "México"
        ]
    },
    {
        numb:18,
        question: "O que é a Eurásia?",
        answer: "Massa que forma em conjunto a Europa e a Ásia",
        options:[
            "Massa que forma em conjunto a Europa e a Ásia",
            "Grupo de países mais influentes do Mundo",
            "Tratado que possibilita aos pesquisadores europeus trabalharem na Ásia",
            "O ar atmosférico em movimento natural"
        ]
    },
];