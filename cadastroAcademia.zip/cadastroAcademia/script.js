const form = document.getElementById("form");
const nome = document.getElementById("nome");
const dataNascimento = document.getElementById("dataNascimento");
const genero = document.getElementById("genero");
const estadoCivil = document.getElementById("estadoCivil");
const objetivo = document.getElementById("objetivo");
const peso = document.getElementById("peso");
const altura = document.getElementById("altura");


form.addEventListener("submit", (e) => {
    e.preventDefault();

    checkInputs();
});

function checkInputs() {
    const nomeValue = nome.value;
    const dataNascimentoValue = dataNascimento.value;
    const pesoValue = peso.value;
    const alturaValue = altura.value;

    if (nomeValue === "") {
        setErrorFor(nome, "O nome de usuário é obrigatório.");
    } else {
        setSuccessFor(nome);
    }

    if (dataNascimentoValue === "") {
        setErrorFor(dataNascimento, "Por favor, insira a Data de Nascimento.");
    } else {
        setSuccessFor(dataNascimento)
    }

    if (pesoValue === "") {
        setErrorFor(peso, "O Peso é obrigatório.");
    } else {
        setSuccessFor(peso);
    }

    if (alturaValue === "") {
        setErrorFor(altura, "A altura é obrigatório.");
    } else {
        setSuccessFor(altura);
    }

    const formControls = form.querySelectorAll(".form-control");

    const formIsValid = [...formControls].every((formControl) => {
        return formControl.className === "form-control success";
    });

    if (formIsValid) {
        console.log("O formulário está 100% válido!");
    }
}

function setErrorFor(input, message) {
    const formControl = input.parentElement;
    const small = formControl.querySelector("small");

    // Adiciona a mensagem de erro
    small.innerText = message;

    // Adiciona a classe de erro
    formControl.className = "form-control error";
}

function setSuccessFor(input) {
    const formControl = input.parentElement;

    // Adicionar a classe de sucesso
    formControl.className = "form-control success";
}