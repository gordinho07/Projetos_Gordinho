//ULTILIZADO PARA PUXAR OS DADOS DA URL ATUAL, E CRIA CADA PARAMETRO
const urlParams = new URLSearchParams(window.location.search);
const nome = urlParams.get('nome');
const dataNascimento = urlParams.get('dataNascimento');
const genero = urlParams.get('genero');
const estadoCivil = urlParams.get('estadoCivil');
const objetivo = urlParams.get('objetivo');
const peso = urlParams.get('peso');
const altura = urlParams.get('altura');

//CALCULO DO IMC
const imc = (peso / (altura * altura)).toFixed(2);

//ULTILIZADO PARA CRIAR UM ID, PARA SER CHAMADO NO HTML
document.getElementById("nome").innerHTML = nome;
document.getElementById("dataNascimento").innerHTML = dataNascimento;
document.getElementById("genero").innerHTML = genero;
document.getElementById("estadoCivil").innerHTML = estadoCivil;
document.getElementById("objetivo").innerHTML = objetivo;
document.getElementById("peso").innerHTML = peso;
document.getElementById("altura").innerHTML = altura;
document.getElementById("imc").innerHTML = imc;

//ULTILIZADO PARA FAZER UMA RECOMENDACAO, COM BASE NO OBJETIVO ESCOLHIDO PELA PESSOA NO FORMULARIO
const recommendationDiv = document.getElementById("recomendacao");
let recommendationText = "";

switch (objetivo) {
    case "Perda de Peso":
        recommendationText = "Para perder peso, recomenda-se a prática regular de exercícios aeróbicos, como caminhadas, corridas e natação, combinada com uma dieta equilibrada e hipocalórica.";
        break;
    case "Ganho de Massa Muscular":
        recommendationText = "Para ganhar massa muscular, recomenda-se a prática regular de exercícios de musculação, combinada com uma alimentação rica em proteínas e carboidratos.";
        break;
    case "Condicionamento Físico":
        recommendationText = "Para melhorar o condicionamento físico, recomenda-se a prática regular de exercícios aeróbicos e anaeróbicos, como corrida, natação, musculação e treinos de alta intensidade.";
        break;
    default:
        recommendationText = "Não foi possível gerar recomendações para o objetivo selecionado.";
        break;
}
recommendationDiv.innerHTML = recommendationText;

//DESCRICAO COM BASE NO INDICE DE MASSA CORPORAL, MAIS CONHECIDO COMO IMC
const calculaIMC = (peso, altura) => {
    if (imc < 18.5) {
        return `Você está abaixo do peso ideal.`;
    } else if (imc >= 18.5 && imc <= 24.9) {
        return `Seu peso está dentro do ideal.`;
    } else if (imc >= 25 && imc <= 29.9) {
        return `Você está com sobrepeso.`;
    } else if (imc >= 30 && imc <= 34.9) {
        return `Você está com obesidade grau I.`;
    } else if (imc >= 35 && imc <= 39.9) {
        return `Você está com obesidade grau II.`;
    } else {
        return `Você está com obesidade grau III.`;
    }
}

document.getElementById('resultado').innerHTML = calculaIMC(peso, altura);

//ULTILIZADO PARA DAR UMA DICA DE DIETA PARA A PESSOA COM BASE NO OBJETIVO ESCOLHIDO PELA PESSOA NO FORMULARIO
let dieta;

switch (objetivo) {
    case 'Perda de Peso':
        dieta = 'Coma menos calorias do que gasta e evite alimentos processados e açúcares';
        break;
    case 'Ganho de Massa Muscular':
        dieta = 'Aumente a ingestão de calorias e consuma mais proteínas para ajudar no ganho de massa muscular';
        break;
    case 'Condicionamento Físico':
        dieta = 'Consuma uma dieta equilibrada e saudável com uma variedade de nutrientes para fornecer energia e suporte ao treinamento';
        break;
    default:
        dieta = 'Objetivo não especificado';
}

document.getElementById("dica").innerHTML = dieta;