var descricao = sessionStorage.getItem("X");


let titulo = document.createElement("h1")
titulo.textContent = "Descrição"
titulo.style.fontFamily = "times";
titulo.style.marginTop = "200px";
titulo.style.color = "black";
titulo.style.textAlign = "center";
titulo.style.fontSize = "25px"


let body = document.querySelector("body")
let ter = document.createElement("p")
ter.textContent = " Ingredientes: " + descricao
ter.style.fontFamily = "times";
ter.style.marginTop = "50px";
ter.style.color = "black";
ter.style.textAlign = "center";
ter.style.fontSize = "20px"

let tempo = document.createElement("p")
tempo.textContent = "Tempo de preparo de 20 a 40 minutos"
tempo.style.fontFamily = "times";
tempo.style.color = "black";
tempo.style.textAlign = "center";
tempo.style.fontSize = "20px"

let voltar = document.createElement("button")
voltar.textContent = "Voltar Cardapio";
voltar.style.fontSize = "20px";
voltar.style.backgroundColor = "yellow";
voltar.style.border = "2px solid yellow";
voltar.style.color = "black";
voltar.style.marginLeft = "45%";
voltar.style.marginTop = "70px";
voltar.addEventListener("click", function(){
    window.location.href="http://127.0.0.1:5500/listaProduto.html";
  })

body.appendChild(titulo)
body.appendChild(ter)
body.appendChild(tempo)
body.appendChild(voltar)