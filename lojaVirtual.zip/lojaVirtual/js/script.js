import { produtos } from "./produtos.js";
import criarTags from "./criarTags.js";
import { criar_Card } from "./criarTags.js";

let body = document.querySelector("body");
let box_card = criarTags("div")
body.appendChild(box_card)
box_card.style.display = "flex"
box_card.style.justifyContent = "space-evenly"
box_card.style.marginBottom = "100px"

for (let l = 0; l <= 4; l++) {
  criar_Card(
    box_card,
    "red",
    produtos[l].fotoProduto,
    produtos[l].nome,
    produtos[l].valor,
    "white",
    produtos[l].descricao
  );
}

let container = criarTags("div");
body.appendChild(container)
container.style.display = "flex"
container.style.justifyContent = "space-evenly"

container.style.marginBottom = "100px"


for (let u = 5; u <= 9; u++) {

criar_Card(
  container,
  "red",
  produtos[u].fotoProduto,
  produtos[u].nome,
  produtos[u].valor,
  "white",
  produtos[u].descricao
);
}

let container2 = criarTags("div");
body.appendChild(container2)
container2.style.display = "flex"
container2.style.justifyContent = "space-evenly"

for (let i = 10; i <= 14; i++) {

criar_Card(
  container2,
  "red",
  produtos[i].fotoProduto,
  produtos[i].nome,
  produtos[i].valor,
  "white",
  produtos[i].descricao
);
}

let voltar = document.createElement("button")
voltar.textContent = "Voltar Inicio";
voltar.style.fontSize = "20px";
voltar.style.backgroundColor = "red";
voltar.style.border = "2px solid red";
voltar.style.color = "white";
voltar.style.marginLeft = "45%";
voltar.style.marginTop = "70px";
voltar.addEventListener("click", function(){
    window.location.href="http://127.0.0.1:5500/index.html";
  })

  body.appendChild(voltar)