export default function criarTags(tag) {
  let tagHTML = document.createElement(tag);

  return tagHTML;
}

export function criar_Card(
  container,
  color_card,
  img_link,
  text,
  text2,
  color,
  descricao
) {
  /*Função estilizar o container do card*/

  var container_card = criarTags("div");
  container_card.style.textAlign = "center";
  container_card.style.borderRadius = "10px";
  container_card.style.width = "350px";
  container_card.style.height = "350px";
  container_card.style.border = "2px solid white";
  container_card.style.backgroundColor = color_card;
  container.appendChild(container_card);

  /*Função para estilazar container da imagem*/

  let container_img = criarTags("div");
  container_img.style.borderRadius = "10px";
  container_img.style.width = "200px";
  container_img.style.height = "200px";
  container_img.style.border = "2px solid white";
  container_img.style.marginRight = "auto";
  container_img.style.marginLeft = "auto";
  container_img.style.marginTop = "10px";
  container_img.style.borderRadius = "100px";
  container_card.appendChild(container_img);

  let img = criarTags("img");
  img.style.width = "100%";
  img.style.height = "100%";
  img.style.borderRadius = "8px";
  img.src = img_link;
  img.style.borderRadius = "99px";
  container_img.appendChild(img);

  /*Função para estilizar o texto*/

  let container_text = criarTags("h2");
  container_text.style.fontFamily = "times";
  container_text.style.marginTop = "15px";
  container_text.textContent = text;
  container_text.style.color = color;
  container_card.appendChild(container_text);

  let container_text2 = criarTags("h3");
  container_text2.style.fontFamily = "times";
  container_text2.style.marginTop = "15px";
  container_text2.textContent = text2;
  container_text2.style.color = color;
  container_card.appendChild(container_text2);

  /*Função para estilizar o botão*/

  let container_button = criarTags("button");
  container_button.textContent = "Saiba Mais";
  container_button.style.fontSize = "20px";
  container_button.style.backgroundColor = "yellow";
  container_button.style.border = "2px solid yellow";
  container_button.style.color = "black";
  container_card.appendChild(container_button)

  
container_button.addEventListener("click", function(){
  window.location.href="http://127.0.0.1:5500/descricao.html";
  sessionStorage.setItem("X", descricao)
})
}