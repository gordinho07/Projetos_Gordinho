export const produtos = [
    {
        fotoProduto: "imagens/pizzaBrocolis.png",
        nome: "Pizza Brocolis",
        valor: "Preço : 38,00",
        descricao: "molho de tomate, brocolis, queijo tipo mussarela",
    },
    {
        fotoProduto: "imagens/pizzaMussarela.png",
        nome: "Pizza Mussarela",
        valor: "Preço : 33.00",
        descricao: "molho de tomate, queijo mussarela, azeitonas, tomate e orégano"
    },
    {
        fotoProduto: "imagens/pizzaCaipira.png",
        nome: "Pizza Caipira",
        valor: "Preço : 36,00",
        descricao: "molho de tomate, queijo mussarela, frango, tomate cereja, calabresa, cebola, milho, pimentão e bacon."
    },
    {
        fotoProduto: "imagens/pizzaCalaBacon.png",
        nome: "Pizza Calabacon",
        valor: "Preço : 37,00",
        descricao: "molho de tomate, calabresa moída, queijo mussarela, bacon fatiada, cebola."
    },
    {
        fotoProduto: "imagens/pizzaCalabresa.png",
        nome: "Pizza Calabresa",
        valor: "Preço : 33,00",
        descricao: "molho de tomate, calabresa, cebola."
    },
    {
        fotoProduto: "imagens/pizzaFrangoCatupiry.png",
        nome: "Pizza Frango Catupiry",
        valor: "Preço : 41,00",
        descricao: "molho de tomate, frango desfiado, catupiry e bacon fatiado."
    },
    {
        fotoProduto: "imagens/pizzaTresQueijos.png",
        nome: "Pizza Três Queijos",
        valor: "Preço : 53,00",
        descricao: "molho de tomate, queijo mussarela ralado, queijo parmesão ralado, queijo gorgonzola e orégano."
    },
    {
        fotoProduto: "imagens/pizzaBacon.png",
        nome: "Pizza Bacon",
        valor: "Preço : 37,00",
        descricao: "molho de tomate, queijo mussarela ralado, bacon fatiado, catupiry, azeitona e orégano."
    },
    {
        fotoProduto: "imagens/pizzaBaiana.jpeg",
        nome: "Pizza Baiana",
        valor: "Preço : 36,00",
        descricao: "molho de tomate, queijo mussarela ralado, presunto ralado, linguiça fatiada, pimenta, cebola e azeitona."
    },
    {
        fotoProduto: "imagens/pizzaItaliana.jpeg",
        nome: "Pizza Italiana",
        valor: "Preço : 43,00",
        descricao: "molho de tomate, queijo mussarela ralado, calabresa fatiada, cogumelo, pimentão e azeitona preta."
    },
    {
        fotoProduto: "imagens/pizzaM&M.jpeg",
        nome: "Pizza m&m",
        valor: "Preço : 40,00",
        descricao: "chocolate ao leite, m&m, leite condensado e granulado."
    },
    {
        fotoProduto: "imagens/pizzaMorango.jpeg",
        nome: "Pizza Morango",
        valor: "Preço : 45,00",
        descricao: "chocolate ao leite, morango, leite condensado e granulado."
    },
    {
        fotoProduto: "imagens/pizzaNapolitana.jpeg",
        nome: "Pizza Napolitana",
        valor: "Preço : 39,00",
        descricao: "molho de tomate, queijo mussarela ralado, rúcula, manjerição, tomate e orégano."
    },
    {
        fotoProduto: "imagens/pizzaPeperoni.jpeg",
        nome: "Pizza Peperoni",
        valor: "Preço : 53,00",
        descricao: "molho de tomate, queijo mussarela ralado, peperoni, pimentão e azeitona."
    },
    {
        fotoProduto: "imagens/pizzaPortuguesa.jpeg",
        nome: "Pizza Portuguesa",
        valor: "Preço : 38,00",
        descricao: "molho de tomate, queijo mussarela ralado, presunto ralado, ovo fatiado, cebola e azeitona."
    },
]